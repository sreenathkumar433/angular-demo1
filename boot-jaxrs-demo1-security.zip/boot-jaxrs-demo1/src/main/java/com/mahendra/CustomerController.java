package com.mahendra;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mahendra.models.Customer;
import com.mahendra.services.CustomerService;

@RestController
@CrossOrigin(origins="http://localhost:4200") 
@RequestMapping("/customers")
public class CustomerController {

	@Autowired private CustomerService service;
	
	@RequestMapping(value="/find-by-id/{id}",
			produces= {MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Customer> find(@PathVariable("id") Integer id) {
		System.out.println("find-by-id *****************");
		Customer customer = null;
		try {
		customer = service.find(id);
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<Customer>(HttpStatus.NO_CONTENT);
		}
	}
	
	@RequestMapping(value="/create",
			method=RequestMethod.POST,
			consumes= {"application/json","application/xml"})
	public ResponseEntity<String> save(@RequestBody Customer customer){
		service.save(customer);
		return new ResponseEntity<String>("Created!",HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/readall", 
			produces= {MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<List<Customer>> retrieveAll() {
		List<Customer> customers = null; 
		try {
			customers = service.findAll();
			return new ResponseEntity<List<Customer>>(customers,HttpStatus.OK);
		}catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<List<Customer>>(HttpStatus.NO_CONTENT);
		}
	}
	
	@RequestMapping(value="/delete/{custID}", method=RequestMethod.DELETE,
			consumes= {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<String> deleteCustomer(@PathVariable("custID") Integer custId) {
		try {
			service.delete(custId);
		return new ResponseEntity<String>(HttpStatus.OK);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value="/update/{custID}", method=RequestMethod.PUT,
			consumes= {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<String> updateCustomer(@RequestBody Customer customer) {
		try {
			service.update(customer);
		return new ResponseEntity<String>(HttpStatus.OK);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
	}
	
}
