package com.sreenadh.dao;

import java.util.List;
import java.util.Optional;

import com.sreenadh.models.Customer;

public interface CustomerDAO{

	List<Customer> retrieveAll();
	Customer findCustomer(Integer custId);
	 Optional<Customer> findByEmail(String email);
	 Optional<Customer> findByFirstName(String email);
	void deleteCustomer(Integer custId);
	void addCustomer(Customer cust);
	void updateCustomer(Customer cust);
}
