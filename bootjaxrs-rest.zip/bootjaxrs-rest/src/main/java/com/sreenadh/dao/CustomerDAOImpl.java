package com.sreenadh.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sreenadh.models.Customer;
import com.sreenadh.repository.CustomerRepository;

@Repository
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	private CustomerRepository customerRepository;
	List<Customer> customerList = null;
	
	
	public CustomerDAOImpl() {
		
		super();
		System.out.println("********************** CustomerDAOImpl class created *****************");
		// TODO Auto-generated constructor stub
	}

	/*
	 * @PostConstruct public void init() { customerList = new ArrayList<>();
	 * customerList.add(new Customer(101,"Sreenadha","Gottipati",
	 * 9848996352L,"sreenathkumar433@gmail.com")); customerList.add(new
	 * Customer(102,"Srikanth","Gottipati", 12131312L,"srikanth@gmail.com"));
	 * customerList.add(new Customer(103,"ramasubbanaidu","Gottipati",
	 * 9874899663L,"sreenathkumar433@gmail.com")); customerList.add(new
	 * Customer(104,"kameswari","Gottipati",
	 * 9848996352L,"sreenathkumar433@gmail.com")); customerList.add(new
	 * Customer(105,"srilakshmi","Gottipati",
	 * 9848996352L,"lakshmisarala@gmail.com")); }
	 */
	
	@Override
	public List<Customer> retrieveAll() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	@Override
	public Customer findCustomer(Integer custId) {
		Optional<Customer> cust = customerRepository.findById(custId);
		// TODO Auto-generated method stub
		//return customerList.stream().filter(x -> x.getCustomerId().equals(custId)).collect(Collectors.toList());
		if(cust.isPresent())
		return cust.get();
		else return null;
	}

	@Override
	public Optional<Customer> findByEmail(String email) {
		Optional<Customer> cust = customerRepository.findByEmail(email);

		//return customerList.stream().filter(x -> x.getEmail().equalsIgnoreCase(email)).findFirst();
		return cust;
	}

	@Override
	public  Optional<Customer> findByFirstName(String name) {
		// TODO Auto-generated method stub
		//return customerList.stream().filter(x -> { return (x.getFirstName().equalsIgnoreCase(name) || x.getLastName().equalsIgnoreCase(name));}).findFirst();
		Optional<Customer> cust = customerRepository.findByFirstName(name);

		//return customerList.stream().filter(x -> x.getEmail().equalsIgnoreCase(email)).findFirst();
		return cust;
	}

	@Override
	public void deleteCustomer(Integer custId) {
		// TODO Auto-generated method stub
		
		customerRepository.deleteById(custId);
	}
	
	public void addCustomer(Customer cust) {
		customerRepository.save(cust);
	}

	@Override
	public void updateCustomer(Customer updateCst) {
		customerRepository.save(updateCst);
		
	}

}
