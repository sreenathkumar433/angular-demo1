package com.sreenadh.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sreenadh.models.Customer;
import com.sreenadh.services.CustomerService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/apvoters/customers")
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	public CustomerController() {
		super();
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$ CustomerController contolr created *****************");
	}
	
	@RequestMapping(value="/loadAll", produces= {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<List<Customer>> retrieveAll() {
		List<Customer> customers = null; 
		try {
			customers = customerService.retrieveAll();
			return new ResponseEntity<List<Customer>>(customers,HttpStatus.OK);
		}catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<List<Customer>>(HttpStatus.NO_CONTENT);
		}
	}
	
	@RequestMapping(value="/find/{cid}", produces={"application/json"})
	public ResponseEntity<Customer> findCustomer(@PathVariable("cid") Integer custId) {
		try {
			Customer custlist = customerService.findCustomer(custId);
			return new ResponseEntity<Customer>(custlist,HttpStatus.OK);
		}catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value="/add", method = RequestMethod.POST,
			consumes= {"application/json","application/xml"})
	public ResponseEntity<String> addCustomer(@RequestBody Customer c) {
		try {
		customerService.addCustomer(c);
		return new ResponseEntity<String>("Created!",HttpStatus.CREATED);
		}catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<String>(HttpStatus.GONE);
		}
	}

	@RequestMapping(value="/update", method = RequestMethod.PUT,
			consumes= {"application/json","application/xml"})
	public ResponseEntity<String> updateCustomer(@RequestBody Customer c) {
		try {
		customerService.updateCustomer(c);
		return new ResponseEntity<String>("Updated!",HttpStatus.NO_CONTENT);
		}catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<String>(HttpStatus.GONE);
		}
	}
	
	@RequestMapping(value="/findByName/{custname}",
			produces={"application/json"})
	public ResponseEntity<Customer> findByName(@PathVariable("custname") String name) {
		try {
			Optional<Customer> cust = customerService.findByFirstName(name);
			if(cust.isPresent()) {
				return new ResponseEntity<Customer>(cust.get(),HttpStatus.OK);
			} else {
				return new ResponseEntity<Customer>(HttpStatus.NO_CONTENT);
				}
		}catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<Customer>(HttpStatus.NO_CONTENT);
	}
	}

	@RequestMapping(value="/delete/{custID}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteCustomer(@PathVariable("custID") Integer custId) {
		try {
		customerService.deleteCustomer(custId);
		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		
	}
	
	

	
}
