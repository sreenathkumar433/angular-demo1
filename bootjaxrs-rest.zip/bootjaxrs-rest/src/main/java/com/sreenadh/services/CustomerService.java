package com.sreenadh.services;

import java.util.List;
import java.util.Optional;

import com.sreenadh.models.Customer;

public interface CustomerService {
	
	List<Customer> retrieveAll();
	Customer findCustomer(Integer custId);
	Optional<Customer> findByEmail(String email);
	Optional<Customer> findByFirstName(String email);
	void deleteCustomer(Integer custId);
	void addCustomer(Customer c);
	void updateCustomer(Customer c);
	

}
