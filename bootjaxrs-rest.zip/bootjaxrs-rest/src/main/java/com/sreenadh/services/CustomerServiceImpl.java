package com.sreenadh.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreenadh.dao.CustomerDAO;
import com.sreenadh.models.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{

	public CustomerServiceImpl() {
		
		super();
		System.out.println("######################### CustomerServiceImpl service created *****************");
		// TODO Auto-generated constructor stub
	}

	@Autowired
	private CustomerDAO customerDao;
	
	@Override
	public List<Customer> retrieveAll() {
		// TODO Auto-generated method stub
		return customerDao.retrieveAll();
	}

	@Override
	public Customer findCustomer(Integer custId) {
		// TODO Auto-generated method stub
		Customer c = customerDao.findCustomer(custId);
		if(c == null) {
			throw new RuntimeException("Customer not found !!");
		}
		return c;
	}

	@Override
	public Optional<Customer> findByEmail(String email) {
		// TODO Auto-generated method stub
		return customerDao.findByEmail(email);
	}

	@Override
	public Optional<Customer> findByFirstName(String name) {
		// TODO Auto-generated method stub
		return customerDao.findByFirstName(name);
	}

	@Override
	public void deleteCustomer(Integer custId) {
		// TODO Auto-generated method stub
		customerDao.deleteCustomer(custId);
	}

	@Override
	public void addCustomer(Customer c) {
		// TODO Auto-generated method stub
		customerDao.addCustomer(c);
	}

	@Override
	public void updateCustomer(Customer c) {
		customerDao.updateCustomer(c);
		
	}

}
