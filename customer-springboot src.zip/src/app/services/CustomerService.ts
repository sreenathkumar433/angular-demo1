import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })
export class CustomerService {

    public static base_url ="http://localhost:8080/";

    
    private http:HttpClient;

    constructor(httpClient:HttpClient) { 
      this.http=httpClient;
    }

    findCustomer(id:number) {
        return this.http.get(CustomerService.base_url+
            "apvoters/customers/find/"+id);
    }
    retrieveCustomers() {
      return this.http.get(CustomerService.base_url+"apvoters/customers/loadAll");
    }


}