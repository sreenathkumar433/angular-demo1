import { Component } from '@angular/core';
import {CustomerService} from './services/CustomerService';
import {Customer} from './models/customer';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'sreenadha kumar gottipati';
  custId:number;
  customer:Customer;
  newCustomer:Customer;
  custList:Customer[];

  private service:CustomerService;
 constructor(service:CustomerService){
   this.service = service;
 }

findCustomer(custId:number) {
    this.service.findCustomer(custId).
    subscribe( 
      (x:any) => {
        this.customer = x;
         console.log(x);
      }
    );
  }

  loadCustomers() {
    this.service.retrieveCustomers().subscribe (
      (x:any) => {
        this.custList = x;

      }
    );
  }

  loadCustomerFields() {
    console.log("load customer");
    this.newCustomer = new Customer(0,"","","","");
  }

  saveCustomer(customerId:Customer) {
    console.log(customerId);
    

  }

  }
