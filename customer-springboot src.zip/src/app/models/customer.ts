export class Customer {

    customerId: number;
    firstName:string;
    lastName:string;
    phoneNo:String;
    email:String;
    
    
   constructor(id:number, fname:string, lname:string, email:string, phone:string){
       this.customerId=id;
       this.firstName=fname;
       this.lastName=lname;
       this.email=email;
       this.phoneNo=phone;
   }
  

}